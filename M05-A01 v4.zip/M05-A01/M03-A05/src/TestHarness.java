import view.LoginUI;
public class TestHarness {

    public static void main(String[] args) {

       LoginUI loginUI = new LoginUI();
    }
}
