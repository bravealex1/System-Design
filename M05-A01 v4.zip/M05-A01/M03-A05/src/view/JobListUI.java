package view;

import controller.JobApplicationController;
import controller.StudentController;
import controller.UserController;
import model.Users.Student;
import model.Users.User;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JobListUI extends JFrame implements ActionListener{

    private JPanel jobListPanel;
    private JButton backButton;
    private JButton applyButton;
    private JComboBox dropDown;
    private JTextArea description;
    private JButton getDescriptionButton;
    private JobApplicationController jobApplicationController;
    private UserController userController;
    private User student;
    private String appliedJob;

    private Integer appliedJobID;

    public JobListUI(User student){

        this.student = student;

        this.add(jobListPanel);
        this.setTitle("Job List");
        this.setSize(800, 400);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        backButton.addActionListener(this);
        applyButton.addActionListener(this);
        getDescriptionButton.addActionListener(this);

        this.setVisible(true);

        try{
            Connection conn= DriverManager.getConnection("jdbc:ucanaccess://M03-A05//DB//OCR_Database.accdb");
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * from Job");
            while (rs.next()) {
                String company = rs.getString("company");
                String job_title = rs.getString("job_title");
                dropDown.addItem(company + " " + job_title);
            }

            st.close();
            rs.close();
            conn.commit();
            conn.close();
        }
        catch (Exception err){
            System.out.println(err.getMessage());
        }
    }

    public void actionPerformed(ActionEvent e) {

        // Handle the back button click event
        if (e.getSource() == backButton) {
            this.userController = new StudentController(student);
            userController.display(student);
            this.setVisible(false);
        }
        else if (e.getSource() == getDescriptionButton) {
            int selectedItem = dropDown.getSelectedIndex();
            selectedItem += 1;
            try{
                Connection conn= DriverManager.getConnection("jdbc:ucanaccess://M03-A05//DB//OCR_Database.accdb");
                Statement st = conn.createStatement();
                ResultSet rs = st.executeQuery("SELECT job_description from Job WHERE job_id = " + selectedItem);
                rs.next();

                String job_description = rs.getString("job_description");
                description.setText(job_description);

                st.close();
                rs.close();
                conn.commit();
                conn.close();
            }
            catch (Exception err){
                System.out.println(err.getMessage());
            }

        }
        else if(e.getSource() == applyButton) {
            int selectedItem = dropDown.getSelectedIndex();
            selectedItem += 1;
            try{
                Connection conn= DriverManager.getConnection("jdbc:ucanaccess://M03-A05//DB//OCR_Database.accdb");
                Statement st = conn.createStatement();
                ResultSet rs = st.executeQuery("SELECT job_title from Job WHERE job_id = " + selectedItem);
                rs.next();

                appliedJob = rs.getString("job_title");
                appliedJobID = selectedItem;

                st.close();
                rs.close();
                conn.commit();
                conn.close();
            }
            catch (Exception err){
                System.out.println(err.getMessage());
            }
            jobApplicationController = new JobApplicationController(student, this);
            this.setVisible(false);
        }
    }

    public String getAppliedJob(){
        return appliedJob;
    }

    public Integer getAppliedJobID(){
        return appliedJobID;
    }
}
