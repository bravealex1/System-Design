package view;

import controller.JobApplicationController;
import model.Users.Alumni;
import model.Users.User;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class StudentGUI extends JFrame implements ActionListener, UserUI  {
    private JLabel studentLabel;
    private JButton viewWorkshop;
    private JButton applyJob;
    private JButton scheduleApp;
    private JButton backButton;
    private User student;
    private LoginUI loginUI;
    private JobListUI jobListUI;

    public StudentGUI(User student){
        this.student = student;
    }

    @Override
    public void getActivityOption() {
        setTitle("Student View");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel studentPanel = new JPanel();
        studentPanel.setLayout(new BoxLayout(studentPanel, BoxLayout.Y_AXIS));
        studentLabel = new JLabel("Welcome " + student.getName() + "!");
        applyJob = new JButton("Apply to Job");
        viewWorkshop = new JButton("View Workshops");
        scheduleApp = new JButton("Schedule Appointment with Advisor");
        backButton = new JButton("Back");

        applyJob.addActionListener(this);
        viewWorkshop.addActionListener(this);
        scheduleApp.addActionListener(this);
        backButton.addActionListener(this);

        studentPanel.add(studentLabel);
        studentPanel.add(applyJob);
        studentPanel.add(viewWorkshop);
        studentPanel.add(scheduleApp);
        studentPanel.add(backButton);

        add(studentPanel);
        this.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {

        // Handle the submit button click event
        if (e.getSource() == applyJob) {
            jobListUI = new JobListUI(student);
            this.setVisible(false);
        }

        // View Workshop Button
        else if (e.getSource() == viewWorkshop) {
            WorkshopListUI workshopListUI = new WorkshopListUI(student);
            this.setVisible(false);
        }
        // Schedule Appointment Button
        else if (e.getSource() == scheduleApp) {
            ScheduleAppointmentUI scheduleAppointmentUI = new ScheduleAppointmentUI(student);
            this.setVisible(false);
        }
        //Back button
        else if (e.getSource() == backButton) {
            loginUI = new LoginUI();
            this.setVisible(false);
        }
    }


}