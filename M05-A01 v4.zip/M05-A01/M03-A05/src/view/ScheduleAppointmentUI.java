package view;

import controller.StudentController;
import controller.UserController;
import model.Users.User;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class ScheduleAppointmentUI extends JFrame implements ActionListener {
    private JLabel studentLabel;
    private JLabel studentNameLabel;
    private JLabel selectAdvisorLabel;
    private JComboBox advisorComboBox;
    private JLabel aptTimeLabel;
    private JComboBox aptTimeComboBox;
    private JButton backButton;
    private JButton submitButton;
    private JComboBox serviceTypeComboBox;
    private JLabel serviceTypeLabel;
    private JPanel scheduleAppointmentPanel;
    private JButton selectDateButton;
    private JLabel dateLabel;
    private User localStudent;

    private UserController userController;

    CalendarGUI calendarGUI;

    public ScheduleAppointmentUI(User student) {

        this.localStudent = student;
        this.add(scheduleAppointmentPanel);
        this.setTitle("Schedule Appointment");
        this.setSize(600, 400);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        this.setVisible(true);

        backButton.addActionListener(this);
        submitButton.addActionListener(this);
        selectDateButton.addActionListener(this);

        studentNameLabel.setText(student.getName());

        aptTimeComboBox.addItem("10AM - 10:30AM");
        aptTimeComboBox.addItem("10:30PM - 10PM");
        aptTimeComboBox.addItem("2PM - 2:30PM");
        aptTimeComboBox.addItem("2:30PM - 3PM");
        aptTimeComboBox.addItem("3PM - 3:30PM");
        aptTimeComboBox.addItem("3:30PM - 4PM");

        serviceTypeComboBox.addItem("Resume Review");
        serviceTypeComboBox.addItem("Interview Practice");
        serviceTypeComboBox.addItem("Career Counselling");
        serviceTypeComboBox.addItem("Elevator Pitch Review");

        try{
            Connection conn= DriverManager.getConnection("jdbc:ucanaccess://M03-A05//DB//OCR_Database.accdb");
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT user_name from User WHERE user_type='Advisor'");
            while (rs.next()) {
                String userName = rs.getString("user_name");
                advisorComboBox.addItem(userName);
            }

            st.close();
            rs.close();
            conn.commit();
            conn.close();
        }
        catch (Exception err){
            System.out.println(err.getMessage());
        }
        calendarGUI = new CalendarGUI();
    }

    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == backButton) {
            this.userController = new StudentController(localStudent);
            userController.display(localStudent);
            this.setVisible(false);

        }
        else if (e.getSource() == selectDateButton) {
            String date = calendarGUI.getDate();
            dateLabel.setText(date);
            selectDateButton.setVisible(false);
        }
        else if (e.getSource() == submitButton) {
            try {
                Connection conn = DriverManager.getConnection("jdbc:ucanaccess://M03-A05//DB//OCR_Database.accdb");

                String selectedAdvisor = advisorComboBox.getSelectedItem().toString();
                String studentName = localStudent.getName();
                String selectedDate = dateLabel.getText();
                String selectedTime = aptTimeComboBox.getSelectedItem().toString();
                String selectedService = serviceTypeComboBox.getSelectedItem().toString();


                String sql = "INSERT INTO Appointment (Advisor, Student, Apt_Date, Apt_Time, Service) "
                        + "VALUES (?, ?, ?, ?, ?)";

                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, selectedAdvisor);
                pstmt.setString(2, studentName);
                pstmt.setString(3, selectedDate);
                pstmt.setString(4, selectedTime);
                pstmt.setString(5, selectedService);

                int rowsInserted = pstmt.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println("A new appointment has been made with " + selectedAdvisor);
                    this.setVisible(false);
                    JOptionPane.showMessageDialog(null, "Appointment Confirmed!");
                    this.userController = new StudentController(localStudent);
                    userController.display(localStudent);
                    this.setVisible(false);

                } else {
                    System.out.println("No rows have been inserted into the Workshop table.");
                }

                conn.commit();
                pstmt.close();
                conn.close();
            }
            catch (Exception err) {
                System.out.println(err.getMessage());
            }

        }
    }

}


