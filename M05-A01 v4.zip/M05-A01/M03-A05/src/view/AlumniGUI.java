package view;

import model.Users.Alumni;
import model.Users.User;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AlumniGUI extends JFrame implements ActionListener, UserUI {

    private JLabel alumniLabel;
    private JButton viewWorkshop;
    private JButton backButton;
    private JButton registerWorkshop;
    private User localAlumni;
    private LoginUI loginUI;

    public AlumniGUI(User alumni) {
        this.localAlumni = alumni;
    }
    @Override
    public void getActivityOption() {
        setTitle("Alumni View");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel alumniPanel = new JPanel();
        alumniPanel.setLayout(new BoxLayout(alumniPanel, BoxLayout.Y_AXIS));
        alumniLabel = new JLabel("Welcome back " + localAlumni.getName() + "!");
        viewWorkshop = new JButton("View Workshops");
        registerWorkshop = new JButton("Set-Up for Workshop");
        backButton = new JButton("Back");

        viewWorkshop.addActionListener(this);
        registerWorkshop.addActionListener(this);
        backButton.addActionListener(this);

        alumniPanel.add(alumniLabel);
        alumniPanel.add(viewWorkshop);
        alumniPanel.add(registerWorkshop);
        alumniPanel.add(backButton);

        add(alumniPanel);

        this.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {

        // View workshop button
        if (e.getSource() == viewWorkshop) {

            WorkshopListUI workshopListUI = new WorkshopListUI(localAlumni);
            this.setVisible(false);
        }
        // Register workshop button
        else if (e.getSource() == registerWorkshop) {
            this.setVisible(false);
            WorkshopGUI workshopGUI = new WorkshopGUI(localAlumni);
        }
        //Back button
        else if (e.getSource() == backButton) {
            loginUI = new LoginUI();
            this.setVisible(false);
        }
    }
}
