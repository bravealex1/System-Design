package view;

import controller.AlumniController;
import controller.StudentController;
import controller.UserController;
import model.Users.User;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class WorkshopListUI extends JFrame implements ActionListener {

    private JPanel workshopListPanel;
    private JLabel workshopList;
    private JLabel workshopDescription;
    private JComboBox listOfWorkshops;
    private JButton getDescription;
    private JButton backButton;
    private JTextArea descriptionArea;

    private User user;
    private UserController userController;

    public WorkshopListUI(User user) {

        this.user = user;

        this.add(workshopListPanel);
        this.setTitle("Workship List");
        this.setSize(800, 400);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        backButton.addActionListener(this);
        getDescription.addActionListener(this);

        this.setVisible(true);

        try{
            Connection conn= DriverManager.getConnection("jdbc:ucanaccess://M03-A05//DB//OCR_Database.accdb");
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * from Workshop");
            while (rs.next()) {

                String name = rs.getString("Workshop_name");


                listOfWorkshops.addItem(name);
            }

            st.close();
            rs.close();
            conn.commit();
            conn.close();
        }
        catch (Exception err){
            System.out.println(err.getMessage());
        }


    }

    public void actionPerformed(ActionEvent e) {

        // Handle the back button click event
        if (e.getSource() == backButton) {

            if (user.getUserType().equals("Student")) {
                this.userController = new StudentController(user);
                userController.display(user);
                this.setVisible(false);
            }
            else if (user.getUserType().equals("Alumni")) {
                this.userController = new AlumniController(user);
                userController.display(user);
                this.setVisible(false);
            }

        }

        else if (e.getSource() == getDescription) {

            int selectedItem = listOfWorkshops.getSelectedIndex();
            selectedItem += 1;

            try{
                Connection conn= DriverManager.getConnection("jdbc:ucanaccess://M03-A05//DB//OCR_Database.accdb");
                Statement st = conn.createStatement();
                ResultSet rs = st.executeQuery("SELECT Description from Workshop WHERE ID = " + selectedItem);
                rs.next();

                String workshopDescription = rs.getString("Description");
                descriptionArea.setText(workshopDescription);

                st.close();
                rs.close();
                conn.commit();
                conn.close();
            }
            catch (Exception err){
                System.out.println(err.getMessage());
            }

        }

    }

}
