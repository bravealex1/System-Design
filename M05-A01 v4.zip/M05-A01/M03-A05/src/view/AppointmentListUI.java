package view;

import controller.AdvisorController;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import controller.UserController;
import model.Users.User;

public class AppointmentListUI extends JFrame implements ActionListener{

    private JTable table;
    private DefaultTableModel tableModel;
    private JButton backButton;
    private User localAdvisor;
    private UserController userController;

    public AppointmentListUI(User advisor) {
        this.localAdvisor = advisor;
        setTitle("Appointment List");
        String[] columnHeaders = {"Student", "Date", "Time", "Service"};
        tableModel = new DefaultTableModel(columnHeaders, 0);
        table = new JTable(tableModel);
        backButton = new JButton("Back");
        backButton.addActionListener(this);
        Container contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());
        contentPane.add(new JScrollPane(table), BorderLayout.CENTER);
        contentPane.add(backButton, BorderLayout.SOUTH);

        setSize(800, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        try{
            Connection conn= DriverManager.getConnection("jdbc:ucanaccess://M03-A05//DB//OCR_Database.accdb");
            PreparedStatement ps = conn.prepareStatement("SELECT * from Appointment WHERE Advisor=?");
            ps.setString(1, localAdvisor.getName());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {

                String student = rs.getString("Student");
                String apt_date = rs.getString("Apt_Date");
                String apt_time = rs.getString("Apt_Time");
                String service = rs.getString("Service");

                this.addRow(student,apt_date,apt_time,service);
            }

            rs.close();
            conn.commit();
            conn.close();
        }
        catch (Exception err){
            System.out.println(err.getMessage());
        }
    }

    public void addRow(String student, String date, String time, String service) {
        Object[] rowData = {student, date, time, service};
        tableModel.addRow(rowData);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == backButton) {
            this.userController = new AdvisorController(localAdvisor);
            userController.display(localAdvisor);
            this.setVisible(false);
        }
    }
}

