package view;


import controller.RecruiterController;
import controller.UserController;
import model.Users.Recruiter;
import model.Users.User;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class NewJobUI extends JFrame implements ActionListener {
    private JTextField companyNameField;
    private JButton submitButton;
    private JTextField locationField;
    private JTextField positionTitleField;
    private JTextField wageField;
    private JLabel recruiterEmailField;
    private JTextArea positionDescriptionField;
    private JButton backButton;
    private JPanel panel;

    private UserController userController;
    private User recruiter;


    public NewJobUI(User recruiter){
        this.recruiter = recruiter;
        this.add(panel);
        this.setTitle("New Job");
        this.setSize(800, 400);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        recruiterEmailField.setText(recruiter.getEmail());

        submitButton.addActionListener(this);
        backButton.addActionListener(this);

        this.setVisible(true);

    }

    public void actionPerformed(ActionEvent e) {

        // Handle the back button click event
        if (e.getSource() == submitButton) {
            try{
                Connection conn= DriverManager.getConnection("jdbc:ucanaccess://M03-A05//DB//OCR_Database.accdb");

                String sql = "INSERT INTO Job (company, job_title, location, job_description, job_wage, recruiter) "
                        + "VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, companyNameField.getText());
                pstmt.setString(2, positionTitleField.getText());
                pstmt.setString(3, locationField.getText());
                pstmt.setString(4, positionDescriptionField.getText());
                pstmt.setString(5, wageField.getText());
                pstmt.setString(6, recruiterEmailField.getText());

                int rowsInserted = pstmt.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println(recruiter.getName() + " added a new Job");
                    JOptionPane.showMessageDialog(null, "New Job Posting added to list! ... heading back");

                    this.userController = new RecruiterController(recruiter);
                    userController.display(recruiter);
                    this.setVisible(false);

                } else {
                    System.out.println("No rows have been inserted into the Workshop table.");
                }
                conn.commit();
                pstmt.close();
                conn.close();
            }
            catch (Exception err){
                System.out.println(err.getMessage());
            }
        }

        else if (e.getSource() == backButton){

            this.userController = new RecruiterController(recruiter);
            userController.display(recruiter);
            this.setVisible(false);
        }
    }
}
