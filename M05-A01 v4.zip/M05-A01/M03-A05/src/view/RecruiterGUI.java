package view;

import model.Users.Recruiter;
import model.Users.User;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RecruiterGUI extends JFrame implements ActionListener, UserUI {
    private JLabel recruiterLabel;
    private JButton backButton;
    private JButton viewApplications;
    private JButton postJob;
    private LoginUI loginUI;
    private User localRecruiter;

    public RecruiterGUI(User recruiter) {
        this.localRecruiter = recruiter;
    }

    @Override
    public void getActivityOption() {
        setTitle("Recruiter View");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel recruiterPanel = new JPanel();
        recruiterPanel.setLayout(new BoxLayout(recruiterPanel, BoxLayout.Y_AXIS));
        recruiterLabel = new JLabel("Welcome " + localRecruiter.getName() + "!");
        postJob = new JButton("Post a Job");
        viewApplications = new JButton("View job applications");
        backButton = new JButton("Back");

        postJob.addActionListener(this);
        viewApplications.addActionListener(this);
        backButton.addActionListener(this);

        recruiterPanel.add(recruiterLabel);
        recruiterPanel.add(postJob);
        recruiterPanel.add(viewApplications);
        recruiterPanel.add(backButton);

        add(recruiterPanel);

        this.setVisible(true);
        }

    public void actionPerformed(ActionEvent e) {

        // Post job button
        if (e.getSource() == postJob) {
            NewJobUI newJobUI = new NewJobUI(localRecruiter);
            this.setVisible(false);
        }

        // View Applications Button
        else if (e.getSource() == viewApplications) {
            ViewApplicationsUI viewApplicationsUI = new ViewApplicationsUI(localRecruiter);
            this.setVisible(false);
        }


        //Back button
        else if (e.getSource() == backButton) {
            LoginUI loginUI = new LoginUI();
            this.setVisible(false);
        }
    }
}
