package view;

import controller.AdvisorController;
import controller.AlumniController;
import controller.RecruiterController;
import controller.StudentController;
import model.OnCampusRecruitment.Job;
import model.OnCampusRecruitment.JobApplication;
import model.Users.Recruiter;
import model.Users.Student;
import model.Users.User;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;

public class JobApplicationUI extends JFrame implements ActionListener {
    private JLabel nameLabel;
    private JLabel nameField;
    private JLabel emailLabel;
    private JLabel emailField;
    private JLabel phoneLabel;
    private JTextField phoneField;
    private JLabel resumeLabel;
    private JButton resumeButton;
    private JLabel coverLetterLabel;
    private JButton coverLetterButton;
    private JButton submitButton;
    private JLabel questionLabel;
    private JTextArea questionTextArea;
    private JLabel yearLabel;
    private String[] options = {"Freshman", "Sophomore", "Junior", "Senior"};
    private JComboBox<String> yearBox;
    private JButton backButton;
    private User localStudent;
    private JobListUI jobListUI;
    private Recruiter recruiter;

    public JobApplicationUI(User student, JobListUI jobListUI) {
        super();
        this.jobListUI = jobListUI;
        this.setTitle("Job Application for " + jobListUI.getAppliedJob());

        nameLabel = new JLabel("Name: ");
        nameField = new JLabel(student.getName());
        emailLabel = new JLabel("PSU email: ");
        emailField = new JLabel(student.getEmail());
        phoneLabel = new JLabel("Phone: ");
        phoneField = new JTextField(20);
        resumeLabel = new JLabel("Resume: ");
        resumeButton = new JButton("select");
        coverLetterLabel = new JLabel("Cover Letter: ");
        coverLetterButton = new JButton("select");
        questionLabel = new JLabel("What makes you the best candidate for this job? ");
        questionTextArea = new JTextArea(10, 40);
        yearLabel = new JLabel("Year: ");
        yearBox = new JComboBox<>(options);

        submitButton = new JButton("Submit");
        submitButton.addActionListener(this);

        backButton = new JButton("Back");
        backButton.addActionListener(this);

        JPanel mainPanel = new JPanel(new BorderLayout());

        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.anchor = GridBagConstraints.LINE_END;
        formPanel.add(nameLabel, c);
        c.gridx = 1;
        c.anchor = GridBagConstraints.LINE_START;
        formPanel.add(nameField, c);
        c.gridx = 0;
        c.gridy = 1;
        c.anchor = GridBagConstraints.LINE_END;
        formPanel.add(emailLabel, c);
        c.gridx = 1;
        c.anchor = GridBagConstraints.LINE_START;
        formPanel.add(emailField, c);
        c.gridx = 0;
        c.gridy = 2;
        c.anchor = GridBagConstraints.LINE_END;
        formPanel.add(phoneLabel, c);
        c.gridx = 1;
        c.anchor = GridBagConstraints.LINE_START;
        formPanel.add(phoneField, c);
        c.gridx = 0;
        c.gridy = 3;
        c.anchor = GridBagConstraints.LINE_END;
        formPanel.add(resumeLabel, c);
        c.gridx = 1;
        c.anchor = GridBagConstraints.LINE_START;
        formPanel.add(resumeButton, c);
        c.gridx = 0;
        c.gridy = 4;
        c.anchor = GridBagConstraints.LINE_END;
        formPanel.add(coverLetterLabel, c);
        c.gridx = 1;
        c.anchor = GridBagConstraints.LINE_START;
        formPanel.add(coverLetterButton, c);
        c.gridx = 0;
        c.gridy = 5;
        c.anchor = GridBagConstraints.LINE_END;
        formPanel.add(questionLabel, c);
        c.gridx = 1;
        c.anchor = GridBagConstraints.LINE_START;
        formPanel.add(new JScrollPane(questionTextArea), c);
        c.gridx = 0;
        c.gridy = 6;
        c.anchor = GridBagConstraints.LINE_END;
        formPanel.add(yearLabel, c);
        c.gridx = 1;
        c.anchor = GridBagConstraints.LINE_START;
        formPanel.add(yearBox, c);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(submitButton);
        buttonPanel.add(backButton);


        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);

        localStudent = student;
    }

    public void actionPerformed(ActionEvent e) {
        // Handle the back button click event
        if (e.getSource() == backButton) {
            jobListUI = new JobListUI(localStudent);
            this.setVisible(false);
        }
        else if (e.getSource() == submitButton) {
            try {
                Connection conn = DriverManager.getConnection("jdbc:ucanaccess://M03-A05//DB//OCR_Database.accdb");
                String email = localStudent.getEmail();
                String phone = phoneField.getText();
                String question = questionTextArea.getText();
                String current_year = yearBox.getSelectedItem().toString();
                Integer job_id = jobListUI.getAppliedJobID();

                String sql = "INSERT INTO Job_Application (job_ID, student_email, phone, current_year, job_question) "
                        + "VALUES (?, ?, ?, ?, ?)";
                PreparedStatement pstmt = conn.prepareStatement(sql);

                // Set the parameter values for the prepared statement
                pstmt.setInt(1, job_id); // job_ID
                pstmt.setString(2, email); // student_email
                pstmt.setString(3, phone); // phone
                pstmt.setString(4, current_year); // current_year
                pstmt.setString(5, question); // job_question

                // Execute the insert statement
                int rowsInserted = pstmt.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println(localStudent.getName() + " has applied for " + jobListUI.getAppliedJob());
                } else {
                    System.out.println("No rows have been inserted into the Job_Application table.");
                }
                conn.commit();
                pstmt.close();
                conn.close();

            } catch (Exception err) {
                System.out.println(err.getMessage());
            }


            this.setVisible(false);
            JOptionPane.showMessageDialog(null, "Application Submitted! ... heading back to job list page");
            jobListUI = new JobListUI(localStudent);
        }
    }

}
