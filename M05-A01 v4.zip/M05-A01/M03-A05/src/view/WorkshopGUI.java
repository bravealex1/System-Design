package view;

import controller.AlumniController;
import controller.StudentController;
import controller.UserController;
import model.Users.Alumni;
import model.Users.User;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class WorkshopGUI extends JFrame implements ActionListener {
    private JPanel panel;
    private JTextField nameField;
    private JTextField dateField;
    private JTextField emailField;
    private JButton registerButton;
    private JTextArea descriptionArea;
    private JButton backButton;
    private UserController userController;

    private User localAlumni;

    public WorkshopGUI(User alumni) {

        this.localAlumni = alumni;

        this.add(panel);
        this.setTitle("Workshop");
        this.setSize(800, 400);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        registerButton.addActionListener(this);
        backButton.addActionListener(this);

        this.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == registerButton) {
            try{
                Connection conn= DriverManager.getConnection("jdbc:ucanaccess://M03-A05//DB//OCR_Database.accdb");

                String sql = "INSERT INTO Workshop (Alumni_email, Workshop_name, Description, Workshop_date) "
                        + "VALUES (?, ?, ?, ?)";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, emailField.getText());
                pstmt.setString(2, nameField.getText());
                pstmt.setString(3, descriptionArea.getText());
                pstmt.setString(4, dateField.getText());

                int rowsInserted = pstmt.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println( localAlumni.getName() + " created a new Workshop for Students");
                    JOptionPane.showMessageDialog(null, "New workshop added to list!");
                    this.userController = new AlumniController(localAlumni);
                    userController.display(localAlumni);
                    this.setVisible(false);

                } else {
                    System.out.println("No rows have been inserted into the Workshop table.");
                }

                conn.commit();
                pstmt.close();
                conn.close();
            }
            catch (Exception err){
                System.out.println(err.getMessage());
            }
        }
        else if(e.getSource() == backButton){
            this.userController = new AlumniController(localAlumni);
            userController.display(localAlumni);
            this.setVisible(false);
        }
    }
}
