package view;

import controller.AdvisorController;
import controller.AlumniController;
import controller.RecruiterController;
import controller.StudentController;
import model.Users.User;
import controller.UserController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class LoginUI extends JFrame implements ActionListener {

    private JLabel emailLabel;
    private JLabel passwordLabel;
    private JTextField emailTextField;
    private JPasswordField passwordField;
    private JButton submitButton;
    private JButton exitButton;

    private JLabel pwdStrengthIndicatorLabel;
    private JLabel pwdStrengthLabel;
    private String password;

    private User user;
    private UserController userController;

    public LoginUI() {

        // Set up the JFrame
        setTitle("Login");
        setSize(500, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create the email field and label
        emailLabel = new JLabel("Email:");
        emailTextField = new JTextField(20);

        // Create the password field and label
        passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField(20);

        // Create the submit button
        submitButton = new JButton("Submit");
        submitButton.addActionListener(this);

        // Creating the exit button
        exitButton = new JButton("Exit");
        exitButton.addActionListener(this);

        pwdStrengthIndicatorLabel = new JLabel();
        pwdStrengthLabel = new JLabel("Password Strength");


        // Create a panel and add the components to it
        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.add(emailLabel);
        panel.add(emailTextField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(pwdStrengthLabel);
        panel.add(pwdStrengthIndicatorLabel);
        panel.add(submitButton);
        panel.add(exitButton);

        passwordField.addKeyListener(new java.awt.event.KeyAdapter(){
            public void keyReleased(java.awt.event.KeyEvent event){
                updateStrengthMeter();
            }
        });

        // Add the panel to the JFrame
        add(panel);
        setVisible(true);
    }

    private void updateStrengthMeter(){
        password = String.valueOf(passwordField.getPassword());
        int strength = calculatePwdStrength();
        setStrengthLabel(strength);
    }

    public int calculatePwdStrength(){
        int strength = 0;
        String regexArr[] = {"[\\d]", "[a-z]", "[A-Z]", "[@$!%*#?&]"};

        for(String regex : regexArr){
            if(password.matches(".*" + regex + ".*")){
                strength++;
            }
        }
        if(password.length() >= 8){
            strength++;
        }
        return strength;
    }

    public void setStrengthLabel(int strength){
        switch(strength){
            case 0:
            case 1:
                pwdStrengthIndicatorLabel.setForeground(Color.RED);
                pwdStrengthIndicatorLabel.setText("Weak password");
                break;
            case 2:
                pwdStrengthIndicatorLabel.setForeground(Color.ORANGE);
                pwdStrengthIndicatorLabel.setText("Moderate password");
                break;
            case 3:
                pwdStrengthIndicatorLabel.setForeground(Color.GREEN);
                pwdStrengthIndicatorLabel.setText("Strong password");
                break;
            case 4:
                pwdStrengthIndicatorLabel.setForeground(Color.MAGENTA);
                pwdStrengthIndicatorLabel.setText("Very Strong password");
                break;
        }
    }



    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == submitButton) {

            String email = emailTextField.getText();
            String password = new String(passwordField.getPassword());

            try{
                Connection conn= DriverManager.getConnection("jdbc:ucanaccess://M03-A05//DB//OCR_Database.accdb");
                Statement st = conn.createStatement();
                ResultSet rs = st.executeQuery("select user_name, password, user_type from User where email =  \"" + email + "\"");
                if (rs.next()) {
                    String userName = rs.getString("user_name");
                    String userType = rs.getString("user_type");

                    if(rs.getString("password").equals(password)) {

                        System.out.println("Authentication successful");

                        this.user = new User(userName,email,password,userType);
                        this.setVisible(false);


                        if (userType.equals("Student")) {
                            this.userController = new StudentController(this.user);
                        }
                        else if (userType.equals("Advisor")) {
                            this.userController = new AdvisorController(this.user);
                        }
                        else if (userType.equals("Alumni")) {
                            this.userController = new AlumniController(this.user);
                        }
                        else if (userType.equals("Recruiter")) {
                            this.userController = new RecruiterController(this.user);
                        }
                        else {
                            JOptionPane.showMessageDialog(null, "Usertype error, Check database for spelling mistakes");
                        }
                        userController.display(this.user);
                    }

                    else {
                        System.out.println("Authentication failed");
                        JOptionPane.showMessageDialog(null, "User not found. Re-enter login credentials");
                    }
                }
                else {
                    System.out.println("Authentication failed");
                    JOptionPane.showMessageDialog(null, "User email not found. Re-enter login credentials");
                }
            }
            catch (Exception err) {
                System.out.println(err.getMessage());
            }
        }
        else if (e.getSource() == exitButton) {
            System.exit(0);
        }
    }

}


