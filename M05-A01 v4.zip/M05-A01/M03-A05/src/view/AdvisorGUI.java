package view;

import model.Users.Advisor;
import model.Users.User;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdvisorGUI extends JFrame implements ActionListener, UserUI {
    private JLabel advisorLabel;
    private JButton viewAppointments;
    private JButton backButton;
    private LoginUI loginUI;
    private User localAdvisor;

    public AdvisorGUI(User advisor){
        localAdvisor = advisor;
    }
    @Override
    public void getActivityOption() {
        setTitle("Advisor View");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel advisorPanel = new JPanel();
        advisorPanel.setLayout(new BoxLayout(advisorPanel, BoxLayout.Y_AXIS));
        advisorLabel = new JLabel("Welcome " + localAdvisor.getName() + "!");
        viewAppointments = new JButton("View Appointments");
        backButton = new JButton("Back");

        advisorPanel.add(advisorLabel);
        advisorPanel.add(viewAppointments);
        advisorPanel.add(backButton);

        viewAppointments.addActionListener(this);
        backButton.addActionListener(this);

        add(advisorPanel);

        this.setVisible(true);
    }
    public void actionPerformed(ActionEvent e) {

        // View appointments button
        if (e.getSource() == viewAppointments) {
            AppointmentListUI viewAppointment = new AppointmentListUI(localAdvisor);
            this.setVisible(false);
        }

        //Back button
        else if (e.getSource() == backButton) {
            loginUI = new LoginUI();
            this.setVisible(false);
        }
    }
}
