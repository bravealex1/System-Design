package view;

import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.SqlDateModel;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

public class CalendarGUI extends JFrame implements ActionListener {
    private JDatePickerImpl datePicker;
    private String strDate;
    private JLabel welcomeLabel;
    private JLabel dateLabel;
    private JPanel panel;
    private JButton doneButton;

    public CalendarGUI(){



        panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        this.setSize(400, 300);

        welcomeLabel = new JLabel("Please select a date for your Appointment");
        dateLabel = new JLabel("mm-dd-yyyy");

        doneButton = new JButton("Done");
        doneButton.addActionListener(this);

        SqlDateModel model = new SqlDateModel();
        Properties p = new Properties();
        model.setSelected(true);
        p.put("text.day","Day");
        p.put("text.month","Month");
        p.put("text.year","Year");
        JDatePanelImpl datePanel = new JDatePanelImpl(model, p);
        datePicker = new JDatePickerImpl(datePanel, new JFormattedTextField.AbstractFormatter() {
            @Override
            public Object stringToValue(String text) throws ParseException {
                return null;
            }

            @Override
            public String valueToString(Object value) throws ParseException {
                if (value != null) {
                    Calendar cal = (Calendar) value;
                    SimpleDateFormat format = new SimpleDateFormat("MM-dd-yyyy");
                    strDate = format.format(cal.getTime());
                    dateLabel.setText("Date choose: " + strDate);
                    return strDate;
                }
                else
                    return "";
            }
        });

        panel.add(welcomeLabel);
        panel.add(datePicker);
        panel.add(dateLabel);
        panel.add(doneButton);
        this.setVisible(true);
        this.add(panel);
    }

    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == doneButton) {
            this.setVisible(false);
        }
    }

    public String getDate(){
        return strDate;
    }

}
