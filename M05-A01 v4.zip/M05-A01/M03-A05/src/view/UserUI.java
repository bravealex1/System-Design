package view;

import java.util.ArrayList;
import model.Users.User;

public interface UserUI {

    public void getActivityOption();
}
