package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import controller.RecruiterController;
import controller.UserController;
import model.Users.User;

public class ViewApplicationsUI extends JFrame implements ActionListener{

    private JTable table;
    private DefaultTableModel tableModel;
    private JButton backButton;
    private User localRecruiter;
    private UserController userController;

    public ViewApplicationsUI(User recruiter) {
        this.localRecruiter = recruiter;
        setTitle("Applications List");
        String[] columnHeaders = {"Title", "Student", "Phone","Standing","Reasoning"};
        tableModel = new DefaultTableModel(columnHeaders, 0);
        table = new JTable(tableModel);
        backButton = new JButton("Back");
        backButton.addActionListener(this);
        Container contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());
        contentPane.add(new JScrollPane(table), BorderLayout.CENTER);
        contentPane.add(backButton, BorderLayout.SOUTH);

        setSize(800, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        try{
            Connection conn= DriverManager.getConnection("jdbc:ucanaccess://M03-A05//DB//OCR_Database.accdb");
            PreparedStatement ps = conn.prepareStatement("SELECT Job.job_title AS title, Job_Application.student_email AS student, Job_Application.phone AS phone, Job_Application.current_year AS student_year, Job_Application.job_question AS reasoning FROM Job JOIN Job_Application ON Job.Job_ID = Job_Application.job_ID WHERE Job.recruiter=?;");
            ps.setString(1, localRecruiter.getEmail());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {

                String title = rs.getString("title");
                String student = rs.getString("student");
                String phone = rs.getString("phone");
                String student_year = rs.getString("student_year");
                String reasoning = rs.getString("reasoning");

                this.addRow(title, student, phone, student_year, reasoning);
            }

            rs.close();
            conn.commit();
            conn.close();
        }
        catch (Exception err){
            System.out.println(err.getMessage());
        }
    }

    // Method to add a row to the JTable
    public void addRow(String title, String student, String phone, String standing, String reasoning) {
        Object[] rowData = {title, student,phone,standing,reasoning};
        tableModel.addRow(rowData);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == backButton) {
            this.userController = new RecruiterController(localRecruiter);
            userController.display(localRecruiter);
            this.setVisible(false);
        }
    }
}

