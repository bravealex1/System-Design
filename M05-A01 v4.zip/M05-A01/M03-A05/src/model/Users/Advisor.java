package model.Users;

import java.util.List;

public class Advisor extends User{
    
    private String position;
    private List<Student> studentsManaged;

    public Advisor(String name, String email, String pwd, String position, List<Student> studentsManaged) {
        super(name, email, pwd);
        this.position = position;
        this.studentsManaged = studentsManaged;
    }


}
