package model.Users;

import java.util.ArrayList;
import java.util.List;

import model.OnCampusRecruitment.JobApplication;

public class Recruiter extends User{
    private String company;
    private String position;
    private List<JobApplication> jobApplications;

    public Recruiter(String name, String email, String pwd, String company, String position) {
        super(name, email, pwd);
        this.company = company;
        this.position = position;
        this.jobApplications = new ArrayList<>();
    }


    
    //Uses the Object-Oriented Design Pattern to dynamically update the list of applications that the recruiters have received.
    public void addApplication(JobApplication application){
        this.jobApplications.add(application);
    }

}
