package model.Users;

public class Alumni extends User{
    
    private String company;
    private String position;

    public Alumni(String name, String email, String pwd, String company, String position) {
        super(name, email, pwd);
        this.company = company;
        this.position = position;
    }


}
