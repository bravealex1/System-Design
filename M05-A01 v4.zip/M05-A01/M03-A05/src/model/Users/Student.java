package model.Users;

import controller.JobApplicationController;
import model.OnCampusRecruitment.Job;

public class Student extends User {

    private String major;
    private String graduationDate;
    private double GPA;
    private Job job;

    public Student(String name, String email, String pwd, String major, String graduationDate, double GPA, Job job) {
        super(name, email, pwd);
        this.major = major;
        this.graduationDate = graduationDate;
        this.GPA = GPA;
        this.job = job;
    }

    public Student(String name, String email, String pwd, String major, String graduationDate, double GPA) {
        super(name, email, pwd);
        this.major = major;
        this.graduationDate = graduationDate;
        this.GPA = GPA;
        this.job = null;
    }


    public Job getJob() {
        return this.job;
    }

    public void setJob(Job job) {
        this.job = job;
    }
}