package model.CareerServices;

import java.sql.Date;
import java.sql.Time;
import java.util.List;
import model.Users.Alumni;
import model.Users.Student;

public class Workshop{
    private Integer workshopId;
    private String workshopTitle;
    private Alumni alumni;
    private Date date;
    private Time time;
    private String workshopDesc;
    private List<Student> attendees;

    public Workshop(Integer workshopId, String workshopTitle, Alumni alumni, Date date, Time time, String workshopDesc, List<Student> attendees){
        this.workshopId = workshopId;
        this.workshopTitle = workshopTitle;
        this.alumni = alumni;
        this.date = date;
        this.time = time;
        this.workshopDesc = workshopDesc;
        this.attendees = attendees;
    }
}