package model.CareerServices;

import java.sql.Date;
import java.sql.Time;
import model.Users.Advisor;
import model.Users.Student;

public class Appointment {

    private Integer appointmentId;
    private Advisor advisor;
    private Student student;
    private Date date;
    private Time time;
    private String aptType;
    
    public Appointment(Advisor advisor, Student student, Integer appointmentId, Date date, Time time, String aptType){
        this.advisor = advisor;
        this.student = student;
        this.appointmentId = appointmentId;
        this.date = date;
        this.time = time;
        this.aptType = aptType;
    }



    public Student getStudent() {
        return this.student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }


}
