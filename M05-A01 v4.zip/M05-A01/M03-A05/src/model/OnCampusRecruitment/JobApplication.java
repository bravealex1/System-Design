package model.OnCampusRecruitment;

import model.Users.Student;

/**
 * JobApplication
 */
public class JobApplication {

    private int applicationID;
    private Job job;
    private Student student;
    private String phoneNumber;
    private String current_year;
    private String job_question;

    public JobApplication(int applicationID, Job job, Student student, String phoneNumber, String current_year, String job_question) {
        this.applicationID = applicationID;
        this.job = job;
        this.student = student;
        this.phoneNumber = phoneNumber;
        this.current_year = current_year;
        this.job_question = job_question;
    }
}