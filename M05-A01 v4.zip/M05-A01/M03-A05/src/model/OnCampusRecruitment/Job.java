package model.OnCampusRecruitment;

import model.Users.Recruiter;

public class Job {
    
    private int jobID;
    private String company;
    private String job_title;
    private String location;
    private String job_description;
    private String jobPosterName;
    private int job_wage;
    private Recruiter recruiter;

    public Job(int jobID, String company, String job_title, String location, String job_description, String jobPosterName, int job_wage, Recruiter recruiter) {
        this.jobID = jobID;
        this.company = company;
        this.job_title = job_title;
        this.location = location;
        this.job_description = job_description;
        this.jobPosterName = jobPosterName;
        this.job_wage = job_wage;
        this.recruiter = recruiter;
    }

}