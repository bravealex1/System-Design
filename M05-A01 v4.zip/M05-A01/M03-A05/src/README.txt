For our applying to job use case, please use the student login credentials and select 'Apply Job' from the provided options.
Make sure that you enter all the information asked before clicking apply or submit.
The dropdown menu in JobListUI is populated dynamically and the Application table in the database is updated automatically,
once the user submits the application, applies ot the job.

Use Cases:
1. Posting a Job (Recruiter)
    1.b Viewing applications (Recruiter)
2. Applying for a Job (Student)
    2.b Viewing jobs applied for(Recruiter)
3. Hosting a Workshop (Alumni)
    3.b Viewing available Workshop (Student)
4. Booking Career Counselling with an Advisor (Student)
    4. Viewing appointments made (Advisor)
5. Login Authentication (User)

Student Login:
Email: bob.smith@psu.edu
Password: bob12345


Recruiter Login:
Email: david.brown@abcenterprises.com
Password: david12345


Advisor Login:
Email: alexandra.nguyen@psu.edu
Password: alexandra12345


Alumni Login:
Email: brad.guy@psualumni.edu
Password: brad12345


Group Contributions:

Team-Member ID | Team-Member Name | Percentage Efforts in Particular Assignment | Brief of Efforts in the Tasks Contribution
1 | Hardik Jain | 100% | Implemented Observer and a Calendar Picker for design patterns. Helped implement and develop several classes . Helped in restructuring of code and developing GUI..
2 | Alex Zhu | 100% | Implemented Command and Navigation design pattern to create a GUI interface that takes in student’s name and email, and displays them. Helped in implementing the database creation and finding errors in the code.
3 | Aamod Joshi | 100% | Implemented Factory method and drop down UI design pattern. Implemented control flow for the ‘Applying to Job’ use case and made necessary GUIs. Wrote SQL statements for user authentication.
4 | Viraj Joshi | 100% | Implemented State and Password Strength Meter Design Pattern. Helped implement the role based access control and made sure that each user had different permissions as well as making sure the user had a strong password.
5 | Nate Kaval | 100% | Implemented decorator design pattern, access database creation and schema, sql statements for retrieving jobs and inserting new job applications, along with creating view appointments and application UIs and functionality.


