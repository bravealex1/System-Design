package controller;

import model.Users.Student;
import model.Users.User;
import view.JobApplicationUI;
import view.JobListUI;

public class JobApplicationController {

    private JobApplicationUI jobApplicationUI;

    public JobApplicationController(User student, JobListUI jobListUI) {

        jobApplicationUI = new JobApplicationUI(student, jobListUI);
    }
}
