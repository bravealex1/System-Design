package controller;

import model.Users.User;
import view.StudentGUI;

public class StudentController extends UserController{
    private User user;
    public StudentController(User user){
        this.user = user;
    }
    @Override
    public StudentGUI getUserUI(User user) {
        return new StudentGUI(user);
    }
}
