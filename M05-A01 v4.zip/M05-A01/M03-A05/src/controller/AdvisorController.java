package controller;
import model.Users.Advisor;
import model.Users.User;
import view.AdvisorGUI;

public class AdvisorController extends UserController {
    private User user;
    public AdvisorController(User user){
        this.user = user;
    }
    @Override
    public AdvisorGUI getUserUI(User user) {
        return new AdvisorGUI(user);
    }
}
