package controller;

import model.Users.Recruiter;
import model.Users.User;
import view.RecruiterGUI;


public class RecruiterController extends UserController{
    private User user;
    public RecruiterController(User user){
        this.user = user;
    }
    @Override
    public RecruiterGUI getUserUI(User user) {
        return new RecruiterGUI(user);
    }



    
}
