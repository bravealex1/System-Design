package controller;

import model.Users.User;
import view.UserUI;

public abstract class UserController {
    public abstract UserUI getUserUI(User user);

    public void display(User user){
        UserUI userui = getUserUI(user);
        userui.getActivityOption();
    }

}