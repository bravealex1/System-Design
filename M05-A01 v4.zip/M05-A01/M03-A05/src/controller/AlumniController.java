package controller;

import model.Users.Alumni;
import model.Users.User;
import view.AlumniGUI;
import view.StudentGUI;

public class AlumniController extends UserController {
    private User user;
    public AlumniController(User user){
        this.user = user;
    }
    @Override
    public AlumniGUI getUserUI(User user) {
        return new AlumniGUI(user);
    }
    
}
